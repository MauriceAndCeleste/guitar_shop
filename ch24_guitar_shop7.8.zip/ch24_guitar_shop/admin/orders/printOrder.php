<?php include 'view/header.php'; ?>
<?php include 'view/sidebar_admin.php'; 
?>

<main>
    <h1>Shipping Document</h1>
    <br>
    
    <?php echo 'Customer Name:  ' . $customer_name['firstName'] . " " . $customer_name['lastName'] ; ?> 
    <br><br>
    <?php echo 'Order Number:   ' . $orderID ; ?>
   
    
    <table id = "shipping" class = 'shippingDocumentTable'>
        <tr id = "shipping_header">
        <th class="shippingDocumentTable">Quantity</th>
        <th class="shippingDocumentTable">Product Name</th>
        <th class="shippingDocumentTable">Description</th>

        </tr>
        <?php foreach ($customer_items as $customer_item) : ?>
        <tr>
            <td class = "shippingDoc"><?php echo ' ' . $customer_item['quantity']; ?></td> 
            <td class = "shippingDoc"><?php echo ' ' . $customer_item['productName']; ?></td> 
            <td class = "shippingDoc"><?php echo ' ' . $customer_item['description']; ?></td> 
        </tr>   
        <br>
        <br>
        <?php endforeach; ?>
    </table>
    
    <h3><i>Shipping Address</i></h3>
    <ul>
        <?php echo "<strong>Street Address Line 1: </strong>" . $customer_name['line1']; ?><br>
        <?php echo "<strong>Street Address Line 2: </strong>" . $customer_name['line2']; ?><br>
        <?php echo "<strong>City: </strong>" . $customer_name['city']; ?><br>
        <?php echo "<strong>State: </strong>" . $customer_name['state']; ?><br>
        <?php echo "<strong>Zip Code: </strong>" . $customer_name['zipCode']; ?><br>
    </ul>
    <br>
    <br>
</main>
<?php include 'view/footer.php'; ?>