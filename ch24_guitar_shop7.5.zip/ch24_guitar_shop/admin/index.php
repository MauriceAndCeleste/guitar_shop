<?php 
require_once('../util/main.php');
require_once('../model/order_db.php');
//We'll use this page to act as a link to the Order Manager App
$action = filter_input(INPUT_POST, 'action');

if ($action == NULL)
{
    $action = filter_input(INPUT_GET, 'action');
    if ($action == NULL)
    {
        $action = 'orderManager';
    }
}

switch($action)
{
    case 'orderManager':
        $unshippedOrders = get_unfilled_orders_simple();
        $shippedOrders = get_filled_orders_simple();
        include('/orders/orderManager.php');  
    break;
    
    case 'updateOrderStatus':
        $orderID = filter_input(INPUT_POST, 'orderID');
        $success = set_ship_date_status($orderID);
        $unshippedOrders = get_unfilled_orders_simple();
        $shippedOrders = get_filled_orders_simple();
        include('/orders/orderManager.php');
    break;

    case 'printOrder':
        $orderID = filter_input(INPUT_POST, 'orderID');
        $allArrays = print_order($orderID);
        $shippingDocs = array_values($allArrays);
        //customer variable = shippingdocs{customer}
        //items variable
        $customer_name = $shippingDocs('customer');
        $customer_items = filter_input(INPUT_POST, 'items');
        include('/orders/printOrder.php');
    break;
}
?>
