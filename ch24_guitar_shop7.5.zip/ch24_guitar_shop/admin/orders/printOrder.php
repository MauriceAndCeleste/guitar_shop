<?php include 'view/header.php'; ?>
<?php include 'view/sidebar_admin.php'; 
//if (!isset($orderID)){$orderID = '';}
//if (!isset($shippingDocs)){$shippingDocs = '';}
?>

<main>
    <h1>Shipping Document</h1>
    
    <?php echo 'Customer Name: ' . $customer_name ; ?> <br>
    
    <table>
        <?php foreach ($customer_items as $customer_item) : ?>
        <tr>
            <td><?php echo $customer_item['items']; ?></td>
         
        </tr>    
        <?php endforeach; ?>
    </table>
    <br>
    <br>
</main>
<?php include 'view/footer.php'; ?>