<?php



function sendEmail($toEmail, $toName, $message) {

    require_once('PHPMailer.php');

    set_time_limit(0);
    
    $email = new PHPMailer();

    $email->IsSMTP();
    // $email->IsSendmail();
    $email->Host       = 'smtp.gmail.com';   //Will need to be modified
    $email->SMTPAuth   = true;  
    $email->Port       = 465;
    $email->SMTPDebug  = 1; 
    $email->Username   = 'mfridaytester@gmail.com';
    $email->Password   = 'fridaytester';  
    //$email->SMTPSecure = 'tls';  
    $email->SMTPSecure = 'ssl';  

    $email->From      = 'mfridaytester@gmail.com';
    $email->FromName  = 'Maurice Friday'; //Will need to be modified – identifies email of sender
    $email->SetFrom('MyGuitarShopNoReply@gmail.com', 'My Guitar Shop');  //Will need to be modified – identifies email of sender
    $email->MsgHTML($message);
    
    $email->AddAddress($toEmail, $toName);

    $email->Subject   = 'Order Confirmation'; // appears in subject of email
    $email->Body      = $message;  
    $email->Send();



    /* AddAddress method identifies destination and sends email	
     if(!$email->Send()) {
     echo "Mailer Error: " . $email->ErrorInfo;
      } else {
       echo "Message sent!";
      }*/

    }

?>
