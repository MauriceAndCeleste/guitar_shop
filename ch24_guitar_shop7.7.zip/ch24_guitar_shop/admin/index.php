<?php 
require_once('../util/main.php');
require_once('../model/order_db.php');
require_once('../model/address_db.php');
//We'll use this page to act as a link to the Order Manager App
$action = filter_input(INPUT_POST, 'action');

if ($action == NULL)
{
    $action = filter_input(INPUT_GET, 'action');
    if ($action == NULL)
    {
        $action = 'orderManager';
    }
}

switch($action)
{
    case 'orderManager':
        $unshippedOrders = get_unfilled_orders_simple();
        $shippedOrders = get_filled_orders_simple();
        include('/orders/orderManager.php');  
    break;
    
    case 'updateOrderStatus':
        $orderID = filter_input(INPUT_POST, 'orderID');
        $success = set_ship_date_status($orderID);
        $unshippedOrders = get_unfilled_orders_simple();
        $shippedOrders = get_filled_orders_simple();
        include('/orders/orderManager.php');
    break;

    case 'printOrder':
        $orderID = filter_input(INPUT_POST, 'orderID');
        $address_id = filter_input(INPUT_POST, 'address_ID');
        $shippingDocs = print_order($orderID);
        $customer_name = $shippingDocs['customer'];
        $customer_items = $shippingDocs['items'];
        $shipping_address = get_address($address_id);
        include('/orders/printOrder.php');
    break;
}
?>
