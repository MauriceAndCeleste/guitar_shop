<?php include 'view/header.php'; ?>
<?php include 'view/sidebar_admin.php'; 
//if (!isset($orderID)){$orderID = '';}
//if (!isset($shippingDocs)){$shippingDocs = '';}
?>

<main>
    <h1>Shipping Document</h1>
    
    <?php echo 'Customer Name: ' . $customer_name['firstName'] . " " . $customer_name['lastName'] ; ?> <br>
    
    <table>
        <?php foreach ($customer_items as $customer_item) : ?>
        <tr>
            <td><?php echo 'Quantity: ' . $customer_item['quantity']; ?></td>
            <td><?php echo 'Order Number: ' . $customer_item['orderID']; ?></td>
            <td><?php echo 'Item ID: ' . $customer_item['itemID']; ?></td>
            <td><?php echo 'Product ID: ' . $customer_item['productID']; ?></td>
        </tr>    
        <?php endforeach; ?>
    </table>
    
    <h2>Shipping Address</h2>
        <?php echo 'Shipping Address ID: ' . $customer_item['shipAddressID']; ?>
        <?php echo 'Street Address: ' . $shipping_address['line1']; ?>
    <br>
    <br>
</main>
<?php include 'view/footer.php'; ?>