﻿<?php
// A possible sendEmail  Function using PHPMailer.php
function sendEmail($order_id) {


// replace XXXXX with appropriate information
require_once('model/class.PHPMailer.php');
require_once('model/class.pop3.php');
require_once('model/class.smtp.php');
require_once('checkout/index.php');
require_once('model/cart.php');

set_time_limit(0);

$order_items = get_order_items($order_id);
$customer = get_customer(get_customer_id($order_id));
$customer_name = $customer['firstName'] . ' ' .
             $customer['lastName'];
$customer_email = $customer['emailAddress'];

$messageHTML = <<<HTML
 <html>
        <head>
            <title>email</title>
        </head>
        <body>
            <font color="green"><b> My Guitar Shop </font></b><br> 
                Thank you for ordering from My Guitar Shop! <br> 
                <br> 
                Your order includes. 
         </body>
 </html>
HTML;
?>        
<?php
     $subtotal = 0;
     $url = 'http://localhost/ch24_guitar_shop/';
     foreach ($order_items as $item) : 
        $product_id = $item['productID'];
        $product_url = $url . 'catalog/?product_id=' . $product_id;
        $product = get_product($product_id);
        $item_name = $product['productName'];
        $list_price = $item['itemPrice'];
        $list_price_txt = sprintf('$%.2f', $list_price);
        $savings = $item['discountAmount'];
        $savings_txt = sprintf('$%.2f', $savings);
        $your_cost = $list_price - $savings;
        $your_cost_txt = sprintf('$%.2f', $your_cost);
        $quantity = $item['quantity'];
        $line_total = $your_cost * $quantity;
        $line_total_txt = sprintf('$%.2f', $line_total);
        $subtotal += $line_total;
?>
<?php      
$messageHTML .= <<<HTML
        <tr>
            <td>href="$product_url" target="_blank"> $item_name </td>
            <td class="right"> $list_price_txt </td>
            <td class="right"> $savings_txt </td>
            <td class="right"> $your_cost_txt </td>
            <td class="right"> $quantity </td>
            <td class="right"> $line_total_txt </td>
        </tr>        
HTML;
$message .= <<<TEXT
            List Price: $list_price_txt;
            Savings:    $savings_txt;
            Your Cost:  $your_cost_txt; 
            Quantity:   $quantity; 
            Line Total: $line_total_txt;
TEXT;
?>
<?php endforeach; ?>
<?php       

$message =  'This is information that will not be HTML friendly for Emails that do not support HTML';
 
//$messageTable= 0;
$email = new PHPMailer();

$email->IsSMTP();

// The XXXXXXXX in the following will need to be adjusted as with Host if not using gmail
// $email->IsSendmail();
$email->Host       = "smtp.gmail.com";   //Will need to be modified
$email->SMTPAuth   = true;  
// $email->Port       = 465;                // The PORTS will vary
$email->Port       = 587;
$email->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)  
$email->SMTPSecure = 'tls';            // ssl is most recent but may need tls 
// $email->SMTPSecure = 'ssl';    
$email->Username   = "brownolive2011"; // SMTP account username Will need to be modified
$email->Password   = "Julcab15";        // SMTP account password Will need to be modified
$email->SetFrom('brownolive2011@gmail.com', 'Celeste');  //Will need to be modified – identifies email of sender
$email->MsgHTML($messageHTML);
$email->SingleTo  = true;	// true allows that only one person will receive an email per array group
$email->From      = 'brownolive2011@gmail.com'; //Will need to be modified – identifies email of sender
$email->FromName  = 'Celeste'; //Will need to be modified – identifies email of sender
$email->Subject   = 'Your Order Confirmation - My Guitar Shop'; // appears in subject of email
$email->Body      = $messageHTML;  // the body will interpret HTML - $messageHTML identified above
$email->AltBody = $messageHTML;            // the AltBody will not interpret HTML - $message identified above
$destination_email_address = $customer_email; // Destination address
$destination_user_name = $customer_name; // Destination name

// $email->AddAddress( 'xxxx@xxxx.xxx' );

//$file_to_attach = 'images.pdf';  // Used if you want attachments to email - This is the name of your attachment file.
                                 // File has to be located in same folder as index.php
//$email->AddAttachment( $file_to_attach ); // Used if you want attachments to email

       //$email->AddAddress($this->$destination_email_address, $destination_user_name); 
       $email->AddAddress($destination_email_address, $destination_user_name);
	// AddAddress method identifies destination and sends email	
         if(!$email->Send()) {
         echo "Mailer Error: " . $email->ErrorInfo;
          } else {
           echo "Message sent!";
          }
}
?>
