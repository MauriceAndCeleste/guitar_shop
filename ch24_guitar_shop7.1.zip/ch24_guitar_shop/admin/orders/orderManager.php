<?php include '../view/header.php'; 
if (!isset($shippedOrders)){$shippedOrders = '';}
if (!isset($unshippedOrders)){$unshippedOrders = '';}
?>
<main>
    <h1>Orders Pending Shipment</h1>
    <table id="pending" class='orderManTable'>
    <tr id="cart_header">
        <th class="left">Order ID</th>
        <th class="right">Order Date</th>
        <th class="right">Status</th>
        <th class="right">&nbsp;</th>
        <th class="right">&nbsp;</th>
    </tr>
    <?php foreach ($unshippedOrders as $unshippedOrder) : 
    $formattedDate = $unshippedOrder['orderDate'];
    $formattedDate = strtotime($formattedDate);
    $formattedDate = date('m-d-Y', $formattedDate);?>
    <tr>
        <td class="center orderMan"><?php echo $unshippedOrder['orderID']; ?></td>
        <td class="center orderMan"><?php echo $formattedDate; ?></td>
        <td class="center orderMan"><?php echo $unshippedOrder['shippingStatus']; ?></td>
        <td class="center orderMan"><form action="." method="post">
                    <input type="hidden" name="action" value="updateOrderStatus">
                    <input type="hidden" name="orderID" value="<?php echo $unshippedOrder['orderID'];?>">
                    <input type="submit" value="Ship Order">
                </form></td>
        <td class="center orderMan"><form action="." method="post">
                    <input type="hidden" name="action" value="printOrder">
                    <input type="hidden" name="orderID" value="<?php echo $unshippedOrder['orderID'];?>">
                    <input type="submit" value="Print Order">
                </form></td>
    </tr>
    <?php endforeach; ?>
    </table><br>
            
    <h1>Orders Shipped</h1>
    <table class='orderManTable'>
    <tr id="cart_header">
        <th class="left">Order ID</th>
        <th class="right">Order Date</th>
        <th class="right">Shipped Date</th>
        <th class="right">Status</th>
    </tr>
    <?php foreach ($shippedOrders as $shippedOrder) :
    $formattedShippedDate = $shippedOrder['shipDate'];
    $formattedShippedDate = strtotime($formattedShippedDate);
    $formattedShippedDate = date('m-d-Y', $formattedShippedDate);
    
    $formattedOrderedDate = $shippedOrder['orderDate'];
    $formattedOrderedDate = strtotime($formattedOrderedDate);
    $formattedOrderedDate = date('m-d-Y', $formattedOrderedDate);?>
    <tr>
        <td class="center orderMan"><?php echo $shippedOrder['orderID']; ?></td>
        <td class="center orderMan"><?php echo $formattedOrderedDate; ?></td>
        <td class="center orderMan"><?php echo $formattedShippedDate; ?></td>
        <td class="center orderMan"><?php echo $shippedOrder['shippingStatus']; ?></td>
    </tr>
    <?php endforeach; ?>
    </table><br>
            
    <p>Return to: <a href="../">Home</a></p>
       
</main>
<?php include '../view/footer.php'; ?>