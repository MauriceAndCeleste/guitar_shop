<?php include 'view/header.php'; ?>
<?php include 'view/sidebar_admin.php'; 
if (!isset($orderID)){$orderID = '';}
if (!isset($shippingDocs)){$shippingDocs = '';}
?>

<main>
    <h1>Shipping Document</h1>
    <table>
        <?php foreach ($shippingDocs as $shippingDoc) : ?>
        <tr>
            <td><?php echo $shippingDoc['firstName']; ?></td>
            <td><?php echo $shippingDoc['lastName']; ?>
                <form action="." method="post">
                    <input type="hidden" name="action" value="printOrder">
                    <input type="hidden" name="orderID" value="<?php echo $shippingDoc['orderID'];?>">
                </form>
            </td>
        </tr>    
        <?php endforeach; ?>
    </table>
    <br>
    <br>
</main>
<?php include 'view/footer.php'; ?>