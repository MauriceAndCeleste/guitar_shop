<?php include '../view/header.php'; 
if (!isset($pendingOrders)){$pendingOrders = '';}
if (!isset($shippedOrders)){$shippedOrders = '';}
?>
<main>
    <h1>Orders Pending Shipment</h1>
    <table id="pending" class='orderManTable'>
    <tr id="cart_header">
        <th class="left">Order ID</th>
        <th class="right">Order Date</th>
        <th class="right">Status</th>
        <th class="right">&nbsp;</th>
        <th class="right">&nbsp;</th>
    </tr>
    <?php //foreach ($pendingOrders as $pendingOrder) : ?>
    <tr>
        <td class="left orderMan">test</td>
        <td class="right orderMan"></td>
        <td class="right orderMan"></td>
        <td class="right orderMan"></td>
        <td class="right orderMan"></td>
    </tr>
    <?php //endforeach; ?>
    </table><br>
            
    <h1>Orders Shipped</h1>
    <table class='orderManTable'>
    <tr id="cart_header">
        <th class="left">Order ID</th>
        <th class="right">Order Date</th>
        <th class="right">Shipped Date</th>
        <th class="right">Status</th>
    </tr>
    <?php //foreach ($shippedOrders as $shippedOrder) : ?>
    <tr>
        <td class="left orderMan"></td>
        <td class="right orderMan"></td>
        <td class="right orderMan"></td>
        <td class="right orderMan"></td>
    </tr>
    <?php //endforeach; ?>
    </table><br>
            
    <p>Return to: <a href="../">Home</a></p>
       
</main>
<?php include '../view/footer.php'; ?>