<?php 
require_once('../util/main.php');
//We'll use this page to act as a link to the Order Manager App
$action = filter_input(INPUT_POST, 'action');

if ($action == NULL)
{
    $action = filter_input(INPUT_GET, 'action');
    if ($action == NULL)
    {
        $action = 'orderManager';
    }
}

switch($action)
{
    case 'orderManager':
      include('/orders/orderManager.php');  
    break;
}
?>
