﻿<?php
// A possible sendEmail  Function using PHPMailer.php
function sendEmail() {


// replace XXXXX with appropriate information
require_once('model/class.PHPMailer.php');
require_once('model/class.pop3.php');
require_once('model/class.smtp.php');
require_once('checkout/index.php');
require_once('model/cart.php');

set_time_limit(0);
 
$messageTable= 0;
$email = new PHPMailer();

$email->IsSMTP();

// The XXXXXXXX in the following will need to be adjusted as with Host if not using gmail
// $email->IsSendmail();
$email->Host       = "smtp.gmail.com";   //Will need to be modified
$email->SMTPAuth   = true;  
// $email->Port       = 465;                // The PORTS will vary
$email->Port       = 587;
$email->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)  
$email->SMTPSecure = 'tls';            // ssl is most recent but may need tls 
// $email->SMTPSecure = 'ssl';    
$email->Username   = "brownolive2011"; // SMTP account username Will need to be modified
$email->Password   = "Julcab15";        // SMTP account password Will need to be modified
$email->SetFrom('brownolive2011@gmail.com', 'Celeste');  //Will need to be modified – identifies email of sender
// $email->MsgHTML($message);
$email->SingleTo  = true;	// true allows that only one person will receive an email per array group
$email->From      = 'brownolive2011@gmail.com'; //Will need to be modified – identifies email of sender
$email->FromName  = 'Celeste'; //Will need to be modified – identifies email of sender
$email->Subject   = 'Your Order Confirmation - My Guitar Shop'; // appears in subject of email
$email->Body      = $messageTable;  // the body will interpret HTML - $messageHTML identified above
//$email->AltBody = $messageTable;            // the AltBody will not interpret HTML - $message identified above
$destination_email_address = 'celestephptester@gmail.com'; // Destination address
$destination_user_name = 'PHPTester'; // Destination name

// $email->AddAddress( 'xxxx@xxxx.xxx' );

//$file_to_attach = 'images.pdf';  // Used if you want attachments to email - This is the name of your attachment file.
                                 // File has to be located in same folder as index.php
//$email->AddAttachment( $file_to_attach ); // Used if you want attachments to email

       //$email->AddAddress($this->$destination_email_address, $destination_user_name); 
       $email->AddAddress($destination_email_address, $destination_user_name);
	// AddAddress method identifies destination and sends email	
         if(!$email->Send()) {
         echo "Mailer Error: " . $email->ErrorInfo;
          } else {
           echo "Message sent!";
          }
}
?>
